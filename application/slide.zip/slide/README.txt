To set up SLIDE run configure_slide.bat

SLIDE has the following dependencies:
1. JDK
2. Glassfish Server
3. MongoDB
4. Python
5. Python Modules: numpy, scipy, and fastcluster

Make sure the above dependencies are installed before running configure_slide.bat

SLIDE has been tested using the following versions of the dependencies:
JDK			1.8
Glassfish Server	4.1.1
MongoDB			3.4
Python			3.5.2
Numpy			
Scipy			
Fastcluster		
